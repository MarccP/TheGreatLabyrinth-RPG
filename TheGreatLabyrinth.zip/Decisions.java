package thegreatlabyrinth;

public class Decisions {
    
    
    public static void decisionch1d1(){
        System.out.println("\n"
                + "[1] Go Out \n"
                + "[2] Inspect the room \n");
        
        
    }
    public static void decisionch1d2(){
        System.out.println("\n"
                + "[1] Left Door \n"
                + "[2] Right Door \n");
       
    }
    public static void decisionch1river(){
        System.out.println("\n"
                + "[1] Drink from the River. \n"
                + "[2] Ignore and Continue walking. \n");
    }    
    public static void decisionch2d2(){
        System.out.println("\n"
                + "[1] Approach the Deer \n"
                + "[2] Ignore the Deer \n");
    }
    
    public static void showstats(){
        System.out.println("\n"
                + "[1] Yes. \n"
                + "[2] No. \n");
    }
    public static void goblins(){
        System.out.println("\n"
                + "[1] Intimidate the Goblins. \n"
                + "[2] Fight the Goblins. \n");
    }
    public static void flowers(){
        System.out.println("\n"
                + "[1] Follow the Flowers. \n"
                + "[2] Ignore the Flowers. \n");
    }
    public static void accessory(){
        System.out.println("\n"
                + "[1] Retrace your Steps. \n"
                + "[2] Find other ways. \n");
    }
    public static void trail(){
        System.out.println("\n"
                + "[1] Follow the Trails. \n"
                + "[2] Ignore the Trails. \n");
    }
    public static void boss(){
        System.out.println("\n"
                + "[1] Fight Giant. \n"
                + "[2] Die. \n");
    }
    public static void bandits(){
        System.out.println("\n"
                + "[1] Confront Them. \n"
                + "[2] Sneak at night. \n");
    }
    public static void sneak(){
        System.out.println("\n"
                + "[1] Tent \n"
                + "[2] Below the Tower \n");
    }
    public static void tentsneak(){
        System.out.println("\n"
                + "[1] Kill the bandit \n"
                + "[2] Throw something to distract \n");
    }
    public static void towersneak(){
        System.out.println("\n"
                + "[1] Kill the bandit \n"
                + "[2] Keep on sneaking \n");
    }
}
